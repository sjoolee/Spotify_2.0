
function[MCS_data]=MCS(data)
    average = mean(data)
    st_dev = std(data);
    MCS_data = (data-average)./st_dev;
