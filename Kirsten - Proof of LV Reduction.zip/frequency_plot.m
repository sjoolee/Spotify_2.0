function[]=frequency_plot(MCS_Musicals,MCS_Indie,MCS_Rock,MCS_Pop,MCS_Lofi)
labels = ["Duration" "Popularity" "Danceability" "Energy" "Key" "Loudness" "Mode" "Speechiness" "Acousticness" "Instrumentalness" "Liveness" "Valence" "Tempo" "Time Signature"];

for i = 1:14

% Create histogram and get bin counts
[Musicals_counts, Musicals_edges] = histcounts(MCS_Musicals(:,i), 30); 
Musicals_binCenters = Musicals_edges(1:end-1) + diff(Musicals_edges)/2;

[Indie_counts, Indie_edges] = histcounts(MCS_Indie(:,i), 30); 
Indie_binCenters = Indie_edges(1:end-1) + diff(Indie_edges)/2;

[Rock_counts, Rock_edges] = histcounts(MCS_Rock(:,i), 30); 
Rock_binCenters = Rock_edges(1:end-1) + diff(Rock_edges)/2;

[Pop_counts, Pop_edges] = histcounts(MCS_Pop(:,i), 30); 
Pop_binCenters = Pop_edges(1:end-1) + diff(Pop_edges)/2;

[Lofi_counts, Lofi_edges] = histcounts(MCS_Lofi(:,i), 30); 
Lofi_binCenters = Lofi_edges(1:end-1) + diff(Lofi_edges)/2;

% Plot frequency as a line
figure;
plot(Musicals_binCenters, Musicals_counts,'LineWidth', 2);
hold on
plot(Indie_binCenters, Indie_counts,'LineWidth', 2);
hold on
plot(Rock_binCenters, Rock_counts,'LineWidth', 2);
hold on
plot(Pop_binCenters, Pop_counts,'LineWidth', 2);
hold on
plot(Lofi_binCenters, Lofi_counts,'LineWidth', 2);
xlabel(labels(i));
ylabel('Frequency');
legend("Musicals", "Indie", "Rock", "Pop", "Lofi")

end