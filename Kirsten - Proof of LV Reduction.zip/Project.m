%% Acquire Data and Plot Matrix
clc
clear
close all

%read files
Musicals = readmatrix ("Musicals.csv");
Indie = readmatrix ("Indie.csv");
Rock = readmatrix ("Rock.csv");
Pop = readmatrix ("Pop.csv");
Lofi = readmatrix ("Lofi.csv");

%MCS - only numerical data
MCS_Musicals=MCS(Musicals(3:end,10:23));
MCS_Indie=MCS(Indie(3:end,10:23));
MCS_Rock=MCS(Rock(3:end,10:23));
MCS_Pop=MCS(Pop(3:end,10:23));
MCS_Lofi=MCS(Lofi(3:end,10:23));

%density plot 
frequency_plot(MCS_Musicals,MCS_Indie,MCS_Rock,MCS_Pop,MCS_Lofi);

%remove outliers


%plot matrix - mcs
plotmatrix(MCS_Musicals)
title("Musicals")

figure
plotmatrix(MCS_Indie)
title("Indie")

figure
plotmatrix(MCS_Rock)
title("Rock")

figure
plotmatrix(MCS_Pop)
title("Pop")

figure
plotmatrix(MCS_Lofi)
title("Lofi")

