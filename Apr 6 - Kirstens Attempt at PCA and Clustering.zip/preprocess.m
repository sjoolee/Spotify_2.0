%preprocess data to be transformed and MCS

function[preprocess_data]= preprocess(data)
    %data(:,10) = sqrt(data(:,1)); %sqrts duration
    %data(:,4) = 10.^(data(:,4)/10); %fixes loudness
    %data(:,8) = exp(-data(:,8)); %log speech
    %data(:,9) = exp(-data(:,9)); %log acousticness 
    %data(:,20) = sqrt(-data(:,11)); %log liveness
    average = mean(data);
    st_dev = std(data);
    preprocess_data = (data-average)./st_dev;
