function [T, P, R2] = nipalsPCA(X, A)
    tol = 1e-8;
    maxIter = 1000;

    % Center the data
    [n, m] = size(X);

    T = zeros(n, A);  % Scores
    P = zeros(m, A);  % Loadings
    SSR = zeros(1, A);  % Sum of squares explained

    % Total variance (sum of column variances)
    SST = sum(var(X, 0, 1));  % 0 for normalizing by n

    for i = 1:A
        t_a = X(:,1);  % Initialize t as first column

        for iter = 1:maxIter
            p_a = (X' * t_a) / (t_a' * t_a);
            p_a = p_a / norm(p_a);  % Normalize p

            t_new = X * p_a;

            if norm(t_new - t_a) < tol
                break;
            end

            t_a = t_new;
        end

        % Store results
        T(:, i) = t_a;
        P(:, i) = p_a;

        % Explained variance of this PC
        X_recon = t_a * p_a';
        SSR(i) = sum(var(X_recon, 0, 1));  % variance of each column
        X = X - X_recon;  % Deflate X
    end

    R2 = cumsum(SSR / SST);  % Cumulative R²
end
