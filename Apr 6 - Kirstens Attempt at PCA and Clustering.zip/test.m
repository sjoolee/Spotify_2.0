%% Acquire Data and Plot Matrix
clc
clear
close all

%read files
Music = readmatrix ("Total.csv");

%MCS - only numerical data
preprocess_music=preprocess(Music(3:end,10:23));

A = 4;

[T, P, R2] = nipalsPCA(preprocess_music, A)

labels = ["Duration" "Popularity" "Danceability" "Energy" "Key" "Loudness" "Mode" "Speechiness" "Acousticness" "Instrumentallnes" "Liveness" "Valence" "Tempo" "Time Signature"] ;
F1 = loading_plot(P(:,1),1,labels); %acousticness, energy, loudness, valence - peppiness 
F1 = loading_plot(P(:,2),3,labels); % danceability, duration, instrumentalness - chill vibes - musicness?
F1 = loading_plot(P(:,3),3,labels); %speechiness, danceability, liveness - yappage
F1 = loading_plot(P(:,4),4,labels);


%clustering
% Assume T is your PCA score matrix (e.g., T(:,1:3))
T_reduced = T(:, 1:3);

% Cluster using custom k-means
k = 6;  % Number of clusters
[idx, centroids] = KMeans(T_reduced, k);

% Plot results (3D example)
songs = readtable("Total.csv");
songs_titles = (songs(3:end,2));  % must be a cell array of strings
scatter3(T_reduced(:,1), T_reduced(:,2), T_reduced(:,3), 50, idx, 'filled');
hold on;
scatter3(centroids(:,1), centroids(:,2), centroids(:,3), 100, 'kx', 'LineWidth', 2);
xlabel('PC1'); ylabel('PC2'); zlabel('PC3');
title('K-Means Clustering (From Scratch)');
grid on;
